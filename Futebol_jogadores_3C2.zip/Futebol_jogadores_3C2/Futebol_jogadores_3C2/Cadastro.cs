﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futebol_jogadores_3C2
{
    public partial class Cadastro : Form
    {
        Usuario objusuario = new Usuario();
        public Cadastro()
        {
            InitializeComponent();
        }

        private void btn_cadastrar_Click(object sender, EventArgs e)
        {
            Usuario objusuario = new Usuario();
            objusuario.nome = txtNome.Text;
            objusuario.email = txtEmail.Text;
            objusuario.senha = txtSenha.Text;

            objusuario.CadastrarUsuario();
            MessageBox.Show("Usuario cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtSenha.Clear();
            txtNome.Clear();
            txtEmail.Clear();
        }
    }
}
