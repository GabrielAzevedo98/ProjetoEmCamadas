﻿namespace Futebol_jogadores_3C2
{
    partial class jogdaores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.btn_cadastrar = new System.Windows.Forms.Button();
            this.lbl_senha = new System.Windows.Forms.Label();
            this.txtIdade = new System.Windows.Forms.TextBox();
            this.cbx_posicao = new System.Windows.Forms.ComboBox();
            this.btn_sair = new System.Windows.Forms.Button();
            this.dtgJogadores = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dtgJogadores)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_nome
            // 
            this.lbl_nome.AutoSize = true;
            this.lbl_nome.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nome.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbl_nome.Location = new System.Drawing.Point(114, 54);
            this.lbl_nome.Name = "lbl_nome";
            this.lbl_nome.Size = new System.Drawing.Size(132, 16);
            this.lbl_nome.TabIndex = 20;
            this.lbl_nome.Text = "Nome do jogadores:";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(114, 73);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(507, 26);
            this.txtNome.TabIndex = 19;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblEmail.Location = new System.Drawing.Point(114, 124);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(124, 16);
            this.lblEmail.TabIndex = 18;
            this.lblEmail.Text = "Posição no campo:";
            // 
            // btn_cadastrar
            // 
            this.btn_cadastrar.BackColor = System.Drawing.Color.ForestGreen;
            this.btn_cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cadastrar.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_cadastrar.Location = new System.Drawing.Point(242, 190);
            this.btn_cadastrar.Name = "btn_cadastrar";
            this.btn_cadastrar.Size = new System.Drawing.Size(308, 75);
            this.btn_cadastrar.TabIndex = 17;
            this.btn_cadastrar.Text = "Cadastrar";
            this.btn_cadastrar.UseVisualStyleBackColor = false;
            this.btn_cadastrar.Click += new System.EventHandler(this.btn_cadastrar_Click);
            // 
            // lbl_senha
            // 
            this.lbl_senha.AutoSize = true;
            this.lbl_senha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_senha.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbl_senha.Location = new System.Drawing.Point(425, 124);
            this.lbl_senha.Name = "lbl_senha";
            this.lbl_senha.Size = new System.Drawing.Size(46, 16);
            this.lbl_senha.TabIndex = 16;
            this.lbl_senha.Text = "Idade:";
            // 
            // txtIdade
            // 
            this.txtIdade.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdade.Location = new System.Drawing.Point(428, 143);
            this.txtIdade.Name = "txtIdade";
            this.txtIdade.Size = new System.Drawing.Size(193, 26);
            this.txtIdade.TabIndex = 15;
            // 
            // cbx_posicao
            // 
            this.cbx_posicao.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_posicao.FormattingEnabled = true;
            this.cbx_posicao.Items.AddRange(new object[] {
            "Goleiro",
            "Defesa",
            "Meio campo",
            "Ataque"});
            this.cbx_posicao.Location = new System.Drawing.Point(114, 143);
            this.cbx_posicao.Name = "cbx_posicao";
            this.cbx_posicao.Size = new System.Drawing.Size(291, 24);
            this.cbx_posicao.TabIndex = 21;
            // 
            // btn_sair
            // 
            this.btn_sair.Location = new System.Drawing.Point(713, 453);
            this.btn_sair.Name = "btn_sair";
            this.btn_sair.Size = new System.Drawing.Size(75, 23);
            this.btn_sair.TabIndex = 23;
            this.btn_sair.Text = "Sair";
            this.btn_sair.UseVisualStyleBackColor = true;
            this.btn_sair.Click += new System.EventHandler(this.btn_sair_Click);
            // 
            // dtgJogadores
            // 
            this.dtgJogadores.BackgroundColor = System.Drawing.Color.ForestGreen;
            this.dtgJogadores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgJogadores.GridColor = System.Drawing.Color.ForestGreen;
            this.dtgJogadores.Location = new System.Drawing.Point(12, 282);
            this.dtgJogadores.Name = "dtgJogadores";
            this.dtgJogadores.Size = new System.Drawing.Size(695, 194);
            this.dtgJogadores.TabIndex = 24;
            this.dtgJogadores.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgJogadores_CellContentClick);
            // 
            // jogdaores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 488);
            this.Controls.Add(this.dtgJogadores);
            this.Controls.Add(this.btn_sair);
            this.Controls.Add(this.cbx_posicao);
            this.Controls.Add(this.lbl_nome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.btn_cadastrar);
            this.Controls.Add(this.lbl_senha);
            this.Controls.Add(this.txtIdade);
            this.Name = "jogdaores";
            this.Text = "jogdaores";
            ((System.ComponentModel.ISupportInitialize)(this.dtgJogadores)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Button btn_cadastrar;
        private System.Windows.Forms.Label lbl_senha;
        private System.Windows.Forms.TextBox txtIdade;
        private System.Windows.Forms.ComboBox cbx_posicao;
        private System.Windows.Forms.Button btn_sair;
        private System.Windows.Forms.DataGridView dtgJogadores;
    }
}