﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Futebol_jogadores_3C2
{
    class Usuario
    {
        public int codigo;
        public string nome , email, senha;
        public string tabela = "usuario";
        Conexao objConexao = new Conexao();
        
        public void CadastrarUsuario()
        {
            {
                Conexao objConexao = new Conexao();
                //Passi 1: comando sql
                string inserir = $@"insert into {tabela} values(null,'{nome}','{email}','{senha}')";
                //Passo 2: execução do comando sql
                objConexao.ExecutarComando(inserir);
            }
        }
        public void verificarUsuario()
        {
            {
                Conexao objConexao = new Conexao();
                //Passi 1: comando sql
                string verificar = $@"select email, senha from {tabela} where email='{email}' and senha='{senha}'";
                //Passo 2: execução do comando sql
                objConexao.ExecutarComando(verificar);
            }
        }

    }
}
