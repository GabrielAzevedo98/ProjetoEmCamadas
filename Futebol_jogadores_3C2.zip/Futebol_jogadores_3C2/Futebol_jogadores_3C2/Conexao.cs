﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Futebol_jogadores_3C2
{
    class Conexao
    {
        MySqlConnection conexao;

        public void Conectar()
        {
            try
            {
                string conn = "Persist Security Info=false;" +
                              "server = localhost;" +
                              "database = futebol;" +
                              "uid =root; pwd = ";
                //string com informações do banco de dados

                conexao = new MySqlConnection(conn);
                conexao.Open();
            }
            catch (MySqlException Conexao_erro)
            {
                throw new Exception("Não foi possivel conectar ao banco de dados" + Conexao_erro.Message);
            }
        }
        public void ExecutarComando(string sql)
        {
            //conectei
            Conectar();

            //prepara para executar o meu comando SQL
            MySqlCommand comando = new MySqlCommand(sql, conexao);

            //executar o comando SQL
            comando.ExecuteNonQuery();
        }
        public DataTable ExecutarConsulta(string sql)
        {
            //Conectar com o banco de dados
            Conectar();

            //Informações da consulta sql
            MySqlDataAdapter dados = new MySqlDataAdapter(sql, conexao);
            DataTable dt = new DataTable();
            dados.Fill(dt);

            return dt;


        }
    }
}
