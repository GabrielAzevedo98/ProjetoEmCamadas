﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futebol_jogadores_3C2
{
    public partial class Form1 : Form
    {
        Usuario objusuario = new Usuario();
        jogdaores objjogadores = new jogdaores();
        public Form1()
        {
            InitializeComponent();
            
            
        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            objusuario.verificarUsuario();
            MessageBox.Show("Usuario logado", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
            jogdaores formJogadores = new jogdaores();
            formJogadores.ShowDialog();



        }

        private void linkLabelCadastar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            Cadastro formCadastro = new Cadastro();
            
            formCadastro.ShowDialog();
            
        }
    }
}
