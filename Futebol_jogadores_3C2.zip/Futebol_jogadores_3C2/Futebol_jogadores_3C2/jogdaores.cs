﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Futebol_jogadores_3C2
{
    public partial class jogdaores : Form
    {
        jogadores objjogadores = new jogadores();
        public jogdaores()
        {
            InitializeComponent();
            dtgJogadores.DataSource = objjogadores.ListarJogadores();
            
        }

        private void btn_sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_cadastrar_Click(object sender, EventArgs e)
        {
            jogadores obj_jogadores = new jogadores();
            obj_jogadores.idade = double.Parse(txtIdade.Text);
            obj_jogadores.nome = txtNome.Text;
            obj_jogadores.posicao = cbx_posicao.Text;

            obj_jogadores.CadastrarJogador();
            MessageBox.Show("Jogador cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtIdade.Clear();
            txtNome.Clear();
            dtgJogadores.DataSource = objjogadores.ListarJogadores();


        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void dtgJogadores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtNome.Text = dtgJogadores.Rows[e.RowIndex].Cells[0].Value.ToString();
            cbx_posicao.Text = dtgJogadores.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtIdade.Text = dtgJogadores.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
